# this is the ui_aquarium.py file

import random
import os
import json

from PyQt6.QtWidgets import QWidget, QLabel, QPushButton, QFrame, QStackedWidget, QHBoxLayout, QVBoxLayout, QScrollArea, QGridLayout, QSizePolicy
from PyQt6.QtGui import QIcon
from PyQt6.QtCore import Qt, QSize, QTimer, QPropertyAnimation, QEasingCurve, QRect

from ui_components import RoundedBackgroundWidget, StatCard, SpriteSheetFish
from fish_manager import SwimmingFish


class AquariumWidget(QWidget):

    def create_divider(self):
        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.1);
                border: none;
                margin: 0px;
                padding: 0px;
            }
        """)
        divider.setFixedHeight(1)
        return divider

    def create_active_dot(self, parent_btn):
        """Create a turquoise dot indicator below a button"""
        # Attach directly to border_widget so it's not clipped by bottom_buttons
        dot = QLabel(self.border_widget)
        dot.setFixedSize(6, 6)
        dot.setStyleSheet("""
            QLabel {
                background-color: #56D4C9;
                border-radius: 3px;
            }
        """)
        # Position below the button (use global coordinates converted to local)
        btn_global_pos = parent_btn.mapTo(self.border_widget, parent_btn.rect().bottomLeft())
        dot.move(btn_global_pos.x() + (parent_btn.width() // 2) - 3,
                 btn_global_pos.y() + 4)
        dot.hide()
        return dot

    def set_active_button(self, active_name):
        """Switch active dot indicator"""
        # Hide all dots
        self.chest_dot.hide()
        self.fishbowl_dot.hide()
        self.stats_dot.hide()

        # Show selected dot
        if active_name == "chest":
            self.chest_dot.show()
            self.chest_dot.raise_()
        elif active_name == "fishbowl":
            self.fishbowl_dot.show()
            self.fishbowl_dot.raise_()
        elif active_name == "stats":
            self.stats_dot.show()
            self.stats_dot.raise_()

        self.current_active = active_name

    def __init__(self, initial_fish_list=None, time_manager=None):
        super().__init__()

        self.time_manager = time_manager

        self.active_fish_sprites = []
        self.current_fish_count = len(initial_fish_list) if initial_fish_list else 0
        self.collection_view = None

        # Load fish configurations from JSON
        self.load_fish_configs()

        # Window dimensions
        self.window_width = 378
        self.window_height = 460
        self.setFixedSize(self.window_width, self.window_height)

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # Main border frame
        self.border_widget = QFrame(self)
        self.border_widget.setGeometry(0, 0, self.window_width, self.window_height)
        self.border_widget.setStyleSheet("""
            QFrame {
                background-color: rgba(7, 18, 35, 240);
                border-radius: 20px;
            }
        """)

        # Main layout
        main_layout = QVBoxLayout(self.border_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(12)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # ===== TOP BAR =====
        self.top_bar = QWidget()
        self.top_bar.setFixedHeight(26)
        top_bar_layout = QHBoxLayout(self.top_bar)
        top_bar_layout.setContentsMargins(0, 12, 0, 0)

        # Left side - Window controls
        left_controls = QWidget()
        left_layout = QHBoxLayout(left_controls)
        left_layout.setSpacing(6)
        left_layout.setContentsMargins(14, 0, 0, 0)
        left_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self.off_btn = QPushButton()
        self.off_btn.setIcon(QIcon("assets/off_button.png"))
        self.off_btn.setIconSize(QSize(11, 11))
        self.off_btn.setFixedSize(11, 11)
        self.off_btn.setStyleSheet("background: transparent; border: none;")
        self.off_btn.clicked.connect(self.close_app)

        self.minimize_btn = QPushButton()
        self.minimize_btn.setIcon(QIcon("assets/minimize_button.png"))
        self.minimize_btn.setIconSize(QSize(11, 11))
        self.minimize_btn.setFixedSize(11, 11)
        self.minimize_btn.setStyleSheet("background: transparent; border: none;")
        self.minimize_btn.clicked.connect(self.minimize_app)

        left_layout.addWidget(self.off_btn)
        left_layout.addWidget(self.minimize_btn)

        # Center - Title with fish icon
        title_widget = QWidget()
        title_layout = QHBoxLayout(title_widget)
        title_layout.setSpacing(6)
        title_layout.setContentsMargins(0, 0, 0, 0)

        self.title_icon = QPushButton()
        self.title_icon.setIcon(QIcon("assets/glow_fish_icon.png"))
        self.title_icon.setIconSize(QSize(16, 16))
        self.title_icon.setFixedSize(16, 16)
        self.title_icon.setStyleSheet("background: transparent; border: none;")
        self.title_icon.setFlat(True)

        self.title_label = QLabel("Typing Aquarium")
        self.title_label.setStyleSheet("""
            color: white;
            font-size: 11px;
            font-weight: semibold;
            font-family: 'DM Sans';
            background: transparent;
        """)

        title_layout.addWidget(self.title_icon)
        title_layout.addWidget(self.title_label)
        title_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Right side - Settings controls
        right_controls = QWidget()
        right_layout = QHBoxLayout(right_controls)
        right_layout.setSpacing(12)
        right_layout.setContentsMargins(0, 0, 14, 0)
        right_layout.setAlignment(Qt.AlignmentFlag.AlignRight)

        self.settings_btn = QPushButton()
        self.settings_btn.setIcon(QIcon("assets/settings_icon.png"))
        self.settings_btn.setIconSize(QSize(13, 13))
        self.settings_btn.setFixedSize(13, 13)
        self.settings_btn.setStyleSheet("background: transparent; border: none;")

        self.view_btn = QPushButton()
        self.view_btn.setIcon(QIcon("assets/minimal_mode_icon.png"))
        self.view_btn.setIconSize(QSize(13, 13))
        self.view_btn.setFixedSize(13, 13)
        self.view_btn.setStyleSheet("background: transparent; border: none;")

        self.pin_btn = QPushButton()
        self.pin_btn.setIcon(QIcon("assets/pin_deactivate_button.png"))
        self.pin_btn.setIconSize(QSize(13, 13))
        self.pin_btn.setFixedSize(13, 13)
        self.pin_btn.setStyleSheet("background: transparent; border: none;")

        right_layout.addWidget(self.settings_btn)
        right_layout.addWidget(self.view_btn)
        right_layout.addWidget(self.pin_btn)

        self.large_mode = True
        self.view_btn.clicked.connect(self.toggle_view_mode)

        top_bar_layout.addWidget(left_controls)
        top_bar_layout.addWidget(title_widget)
        top_bar_layout.addWidget(right_controls)
        top_bar_layout.setStretch(0, 1)
        top_bar_layout.setStretch(1, 2)
        top_bar_layout.setStretch(2, 1)

        main_layout.addWidget(self.top_bar)

        # ===== DIVIDER 1 =====
        divider1 = self.create_divider()
        main_layout.addWidget(divider1)
        self.divider1 = divider1

        # ===== CONTENT STACK (Aquarium OR Collection) =====
        self.content_stack = QStackedWidget()
        self.content_stack.setStyleSheet("background: transparent;")

        # Create aquarium content
        self.aquarium_content = QWidget()
        aquarium_layout = QVBoxLayout(self.aquarium_content)
        aquarium_layout.setContentsMargins(0, 0, 0, 0)
        aquarium_layout.setSpacing(0)

        # Aquarium container
        aquarium_width = 354
        aquarium_height = 275

        self.aquarium_container = QWidget()
        self.aquarium_container.setFixedSize(aquarium_width, aquarium_height)
        self.aquarium_container.setStyleSheet("background: transparent;")
        self.aquarium_container.setObjectName("aquarium_container")

        self.background_widget = RoundedBackgroundWidget(self.aquarium_container)
        self.background_widget.setGeometry(0, 0, aquarium_width, aquarium_height)
        self.background_widget.set_image_path("assets/aquarium_background.png")
        self.background_widget.set_water_overlay(True)
        self.background_widget.lower()

        # Fish count overlay
        self.fish_count_widget = QWidget(self.aquarium_container)
        self.fish_count_widget.setGeometry(aquarium_width - 88, 8, 80, 30)
        self.fish_count_widget.setStyleSheet("""
            background: rgba(0, 0, 0, 0.5);
            border-radius: 15px;
        """)

        fish_count_layout = QHBoxLayout(self.fish_count_widget)
        fish_count_layout.setContentsMargins(12, 0, 8, 0)
        fish_count_layout.setSpacing(8)

        self.fish_count_icon = QPushButton()
        self.fish_count_icon.setIcon(QIcon("assets/fish_count_icon.png"))
        self.fish_count_icon.setIconSize(QSize(18, 18))
        self.fish_count_icon.setFixedSize(18, 18)
        self.fish_count_icon.setStyleSheet("background: transparent; border: none;")
        self.fish_count_icon.setFlat(True)
        self.fish_count_icon.setEnabled(True)

        self.fish_count_label = QLabel(f"{self.current_fish_count} fish")
        self.fish_count_label.setStyleSheet("""
            color: #FFFFFF;
            font-size: 10px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: transparent;
        """)

        fish_count_layout.addWidget(self.fish_count_icon)
        fish_count_layout.addWidget(self.fish_count_label)
        self.fish_count_widget.raise_()

        aquarium_layout.addWidget(self.aquarium_container, alignment=Qt.AlignmentFlag.AlignCenter)

        # Stats cards
        self.stats_container = QWidget()
        stats_layout = QHBoxLayout(self.stats_container)
        stats_layout.setSpacing(8)
        stats_layout.setContentsMargins(0, 12, 0, 0)

        self.chars_card = StatCard("Chars today")
        self.wpm_card = StatCard("wpm")
        self.focus_card = StatCard("Total typing time")

        stats_layout.addWidget(self.chars_card, 1)
        stats_layout.addWidget(self.wpm_card, 1)
        stats_layout.addWidget(self.focus_card, 1)

        aquarium_layout.addWidget(self.stats_container, alignment=Qt.AlignmentFlag.AlignCenter)

        self.content_stack.addWidget(self.aquarium_content)
        self.content_stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        # Create collection content (empty for now, will be populated when needed)
        self.collection_content = QWidget()
        self.content_stack.addWidget(self.collection_content)

        main_layout.addWidget(self.content_stack)

        # ===== DIVIDER 2 =====
        divider2 = self.create_divider()
        main_layout.addWidget(divider2)
        self.divider2 = divider2

        # ===== BOTTOM BUTTONS =====
        self.bottom_buttons = QWidget()
        bottom_layout = QHBoxLayout(self.bottom_buttons)
        bottom_layout.setSpacing(24)
        bottom_layout.setContentsMargins(0, 0, 0, 0)

        self.chest_btn = QPushButton()
        self.chest_btn.setIcon(QIcon("assets/treasure_chest_icon.png"))
        self.chest_btn.setIconSize(QSize(24, 24))
        self.chest_btn.setFixedSize(24, 24)
        self.chest_btn.setStyleSheet("background: transparent; border: none;")

        self.fishbowl_btn = QPushButton()
        self.fishbowl_btn.setIcon(QIcon("assets/fishbowl_icon.png"))
        self.fishbowl_btn.setIconSize(QSize(24, 24))
        self.fishbowl_btn.setFixedSize(24, 24)
        self.fishbowl_btn.setStyleSheet("background: transparent; border: none;")

        self.stats_btn = QPushButton()
        self.stats_btn.setIcon(QIcon("assets/statistics_icon.png"))
        self.stats_btn.setIconSize(QSize(24, 24))
        self.stats_btn.setFixedSize(24, 24)
        self.stats_btn.setStyleSheet("background: transparent; border: none;")

        bottom_layout.addWidget(self.chest_btn)
        bottom_layout.addWidget(self.fishbowl_btn)
        bottom_layout.addWidget(self.stats_btn)
        bottom_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        main_layout.addWidget(self.bottom_buttons)

        # Pin state
        self.pin_state = True
        self.pin_btn.clicked.connect(self.toggle_pin_status)

        # Store aquarium dimensions
        self.aquarium_width = aquarium_width
        self.aquarium_height = aquarium_height

        # Start movement timer
        self.movement_timer = QTimer()
        self.movement_timer.timeout.connect(self.update_fish_positions)
        self.movement_timer.start(20)

        # Spawn initial fish
        if initial_fish_list:
            for fish_id in initial_fish_list:
                self.spawn_fish_sprite(fish_id)

    def setup_collection_content(self):
        """Setup the collection view inside the content stack"""
        layout = QVBoxLayout(self.collection_content)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        # Filter bar
        filter_bar = self.create_filter_bar()
        layout.addWidget(filter_bar)

        # Scrollable fish grid
        self.collection_grid = QScrollArea()
        self.collection_grid.setWidgetResizable(True)
        self.collection_grid.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: rgba(255, 255, 255, 0.1);
                width: 6px;
                border-radius: 3px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 3px;
            }
        """)

        self.collection_grid_container = QWidget()
        self.collection_grid_layout = QGridLayout(self.collection_grid_container)
        self.collection_grid_layout.setSpacing(12)
        self.collection_grid_layout.setContentsMargins(12, 12, 12, 12)

        self.collection_grid.setWidget(self.collection_grid_container)
        layout.addWidget(self.collection_grid)

    def create_filter_bar(self):
        """Create filter tabs (All, Owned, Locked) with discovery counter"""
        filter_bar = QWidget()
        filter_bar.setFixedHeight(20)
        filter_bar.setStyleSheet("background: transparent;")

        layout = QHBoxLayout(filter_bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(0)
        layout.setAlignment(Qt.AlignmentFlag.AlignRight)

        self.all_btn = QPushButton("All")
        self.owned_btn = QPushButton("Owned")
        self.locked_btn = QPushButton("Locked")

        for btn in [self.all_btn, self.owned_btn, self.locked_btn]:
            btn.setFixedSize(60, 30)
            btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: rgba(255, 255, 255, 0.6);
                    border: none;
                    font-size: 12px;
                    font-family: 'DM Sans';
                }
                QPushButton:hover {
                    color: white;
                }
            """)

        self.set_active_filter(self.all_btn)

        self.all_btn.clicked.connect(lambda: self.set_filter("all"))
        self.owned_btn.clicked.connect(lambda: self.set_filter("owned"))
        self.locked_btn.clicked.connect(lambda: self.set_filter("locked"))

        layout.addWidget(self.all_btn)
        layout.addWidget(self.owned_btn)
        layout.addWidget(self.locked_btn)
        layout.addStretch()

        # Discovery counter
        self.discovery_label = QLabel()
        self.discovery_label.setStyleSheet("""
            color: #56D4C9;
            font-size: 12px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: transparent;
        """)
        layout.addWidget(self.discovery_label)

        return filter_bar

    def set_active_filter(self, active_btn):
        """Update active filter button styling"""
        for btn in [self.all_btn, self.owned_btn, self.locked_btn]:
            btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: rgba(255, 255, 255, 0.6);
                    border: none;
                    font-size: 12px;
                    font-family: 'DM Sans';
                }
                QPushButton:hover {
                    color: white;
                }
            """)

        active_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #56D4C9;
                border: none;
                font-size: 12px;
                font-family: 'DM Sans';
                font-weight: bold;
            }
        """)

    def set_filter(self, filter_type):
        """Set current filter and refresh grid"""
        self.current_filter = filter_type
        self.apply_collection_filter()

    def load_collection_data(self):
        """Load fish data for collection view"""
        try:
            with open("fish.json", "r") as f:
                self.all_fish = json.load(f)
            print(f"Loaded {len(self.all_fish)} fish")
        except Exception as e:
            print(f"Error loading fish.json: {e}")
            self.all_fish = []

    def apply_collection_filter(self):
        """Apply current filter and sort, then populate grid"""
        if not self.all_fish:
            self.load_collection_data()
            if not self.all_fish:
                return

        owned_ids = self.time_manager.user_data.get("owned_fish", [])
        viewed_ids = self.time_manager.user_data.get("viewed_fish", [])

        filtered_fish = []
        for fish in self.all_fish:
            is_owned = fish["id"] in owned_ids
            is_new = is_owned and fish["id"] not in viewed_ids

            if self.current_filter == "all":
                filtered_fish.append((fish, is_owned, is_new))
            elif self.current_filter == "owned" and is_owned:
                filtered_fish.append((fish, is_owned, is_new))
            elif self.current_filter == "locked" and not is_owned:
                filtered_fish.append((fish, is_owned, is_new))

        # Sort by rarity (higher number = common first)
        filtered_fish.sort(key=lambda x: x[0].get("rarity", 50), reverse=True)

        # Update discovery counter
        owned_count = len(owned_ids)
        total_count = len(self.all_fish)
        self.discovery_label.setText(f"{owned_count}/{total_count} discovered")

        self.populate_collection_grid(filtered_fish)

    def populate_collection_grid(self, fish_list):
        """Populate the collection grid with fish cards"""
        # Clear existing widgets
        for i in reversed(range(self.collection_grid_layout.count())):
            widget = self.collection_grid_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        columns = 3
        for index, (fish, is_owned, is_new) in enumerate(fish_list):
            row = index // columns
            col = index % columns

            card = self.create_fish_card(fish, is_owned, is_new)
            self.collection_grid_layout.addWidget(card, row, col)

    def create_fish_card(self, fish_data, is_owned, is_new):
        """Create a fish card widget"""
        from PyQt6.QtWidgets import QFrame, QVBoxLayout, QLabel
        from PyQt6.QtGui import QPixmap
        from PyQt6.QtCore import Qt

        card = QFrame()
        card.setFixedSize(110, 130)
        card.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.05);
                border-radius: 12px;
            }
            QFrame:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # Fish image
        image_label = QLabel()
        image_label.setFixedSize(64, 64)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setScaledContents(True)

        if is_owned:
            img_path = f"assets/{fish_data['id']}_swim.png"
            if not os.path.exists(img_path):
                img_path = f"assets/{fish_data['id']}_swim.gif"
            if not os.path.exists(img_path):
                img_path = "assets/default_fish.png"
        else:
            img_path = "assets/default_fish.png"

        pixmap = QPixmap(img_path)
        if not pixmap.isNull():
            image_label.setPixmap(pixmap.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio))

        layout.addWidget(image_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Fish name
        name_label = QLabel(fish_data["name"])
        name_label.setStyleSheet("""
            color: white;
            font-size: 11px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: transparent;
        """)
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(name_label)

        # Rarity badge
        rarity = fish_data.get("rarity", 50)
        if rarity >= 50:
            rarity_text = "COMMON"
            rarity_color = "#56D4C9"
        elif rarity >= 10:
            rarity_text = "RARE"
            rarity_color = "#9B59B6"
        else:
            rarity_text = "LEGENDARY"
            rarity_color = "#F39C12"

        rarity_label = QLabel(rarity_text)
        rarity_label.setStyleSheet(f"""
            color: {rarity_color};
            font-size: 9px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: rgba(0, 0, 0, 0.5);
            padding: 2px 6px;
            border-radius: 10px;
        """)
        rarity_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(rarity_label)

        # New badge
        if is_new and is_owned:
            new_badge = QLabel("NEW")
            new_badge.setStyleSheet("""
                color: #FF6B6B;
                font-size: 9px;
                font-weight: bold;
                font-family: 'DM Sans';
                background: rgba(0, 0, 0, 0.7);
                padding: 2px 6px;
                border-radius: 10px;
            """)
            new_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(new_badge)
        else:
            spacer = QLabel()
            spacer.setFixedHeight(18)
            layout.addWidget(spacer)

        # Lock icon for locked fish
        if not is_owned:
            lock_label = QLabel("🔒")
            lock_label.setStyleSheet("""
                color: rgba(255, 255, 255, 0.7);
                font-size: 20px;
                background: transparent;
            """)
            lock_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(lock_label)

        card.setLayout(layout)

        # Store data on card
        card.fish_id = fish_data["id"]
        card.is_new_flag = is_new

        # Connect click event
        card.mousePressEvent = lambda e, fid=fish_data["id"], n=is_new: self.on_collection_card_clicked(fid, n)

        return card

    def on_collection_card_clicked(self, fish_id, is_new):
        """Handle fish card click - mark as viewed if new"""
        if is_new:
            viewed_ids = self.time_manager.user_data.get("viewed_fish", [])
            if fish_id not in viewed_ids:
                viewed_ids.append(fish_id)
                self.time_manager.user_data["viewed_fish"] = viewed_ids
                self.time_manager.save_state()
            self.apply_collection_filter()

        print(f"Clicked on fish: {fish_id}")

    def toggle_view_mode(self):
        """Toggle between large mode and minimal mode with smooth animation"""

        # Save original window height if not already saved
        if not hasattr(self, 'original_window_height'):
            self.original_window_height = self.height()

        # Get current geometry
        current_rect = self.geometry()

        if self.large_mode:
            # Calculate target size for minimal mode
            target_height = self.top_bar.height() + self.aquarium_container.height() + 25
            target_rect = QRect(current_rect.x(), current_rect.y(),
                                self.window_width, target_height)

            # Fade out stats and buttons
            self.fade_out_widgets()

            # Animate window resize
            self.animate_resize(target_rect)

            # Change icon
            self.view_btn.setIcon(QIcon("assets/large_mode_icon.png"))
            self.large_mode = False

        else:
            # Restore original size
            target_rect = QRect(current_rect.x(), current_rect.y(),
                                self.window_width, self.original_window_height)

            # Animate window resize first
            self.animate_resize(target_rect)

            # Then fade in after resize (using timer)
            QTimer.singleShot(300, self.fade_in_widgets)

            # Change icon
            self.view_btn.setIcon(QIcon("assets/minimal_mode_icon.png"))
            self.large_mode = True

    def animate_resize(self, target_rect):
        """Smoothly animate window resize"""
        self.anim = QPropertyAnimation(self, b"geometry")
        self.anim.setDuration(300)
        self.anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        self.anim.setEndValue(target_rect)
        self.anim.start()

    def fade_out_widgets(self):
        """Fade out stats and buttons"""
        self.stats_container.hide()  # Quick hide for now
        self.bottom_buttons.hide()
        if hasattr(self, 'divider1'):
            self.divider1.hide()
            self.divider2.hide()

    def fade_in_widgets(self):
        """Fade in stats and buttons"""
        self.stats_container.show()
        self.bottom_buttons.show()
        if hasattr(self, 'divider1'):
            self.divider1.show()
            self.divider2.show()

    def create_dots(self):
        """Create active dots after layout is ready"""
        self.chest_dot = self.create_active_dot(self.chest_btn)
        self.fishbowl_dot = self.create_active_dot(self.fishbowl_btn)
        self.stats_dot = self.create_active_dot(self.stats_btn)

        # Ensure dots are on top
        self.chest_dot.raise_()
        self.fishbowl_dot.raise_()
        self.stats_dot.raise_()

        # Set default active (Aquarium)
        self.fishbowl_dot.show()
        self.current_active = "fishbowl"

        # Connect button clicks
        self.chest_btn.clicked.connect(self.show_collection)
        self.fishbowl_btn.clicked.connect(self.show_aquarium)
        self.stats_btn.clicked.connect(lambda: self.set_active_button("stats"))

        # Force repaint
        self.fishbowl_dot.update()
        self.update()

        # Debug: Print final positions
        print(f"Chest button final position: ({self.chest_btn.x()}, {self.chest_btn.y()})")
        print(f"Fishbowl button final position: ({self.fishbowl_btn.x()}, {self.fishbowl_btn.y()})")
        print(f"Fishbowl dot position: ({self.fishbowl_dot.x()}, {self.fishbowl_dot.y()})")

    def show_collection(self):
        """Open collection in a separate window"""
        from collection_widget import CollectionWindow

        # Create and show collection window
        self.collection_window = CollectionWindow(self.time_manager)
        self.collection_window.show()

    def show_aquarium(self):
        """Switch back to aquarium view"""
        # Switch back to original aquarium height
        if hasattr(self, 'aquarium_height_saved'):
            self.setFixedSize(self.window_width, self.aquarium_height_saved)
        else:
            self.setFixedSize(self.window_width, 460)  # Default height

        # Update border widget
        self.border_widget.setGeometry(0, 0, self.width(), self.height())

        # IMPORTANT: Reset aquarium content to its original size
        self.aquarium_content.setFixedSize(self.window_width,
                                           self.aquarium_height_saved or 460 - 100)  # Approximate content height

        # Switch to aquarium content
        self.content_stack.setCurrentWidget(self.aquarium_content)

        # FORCE LAYOUT RECALCULATION
        self.content_stack.updateGeometry()
        self.content_stack.layout().activate()
        self.update()
        self.repaint()

        # Update active button
        self.set_active_button("fishbowl")

        # Update dot visibility
        self.chest_dot.hide()
        self.fishbowl_dot.show()
        self.stats_dot.hide()

    def showEvent(self, event):
        """Called when widget is first shown - create dots after window is visible"""
        super().showEvent(event)
        if not hasattr(self, '_dots_created'):
            # Use a longer delay to ensure layout is completely ready
            QTimer.singleShot(200, self.create_dots)
            self._dots_created = True

    def load_fish_configs(self):
        """Load fish sprite sheet configurations from fish.json"""
        try:
            with open("fish.json", "r") as f:
                fish_data = json.load(f)

            self.fish_configs = {}
            for fish in fish_data:
                fish_id = fish["id"]
                # You can extend this with custom configs per fish
                # For now, use default values that can be overridden in the JSON
                self.fish_configs[fish_id] = {
                    "frame_width": fish.get("frame_width", 128),
                    "frame_height": fish.get("frame_height", 128),
                    "rows": fish.get("sprite_rows", 2),
                    "cols": fish.get("sprite_cols", 4),
                    "fps": fish.get("animation_fps", 10),
                    "default_facing": fish.get("default_facing", "left")
                }
            print(f"Loaded configurations for {len(self.fish_configs)} fish")
        except Exception as e:
            print(f"Error loading fish configs: {e}")
            self.fish_configs = {}

    def get_fish_config(self, fish_id):
        """Get sprite sheet configuration for a fish"""
        if fish_id in self.fish_configs:
            return self.fish_configs[fish_id]
        else:
            # Default configuration
            return {
                "frame_width": 128,
                "frame_height": 128,
                "rows": 2,
                "cols": 4,
                "fps": 10,
                "default_facing": "left"
            }

    def update_fish_positions(self):
        """Update positions of all swimming fish"""
        if not hasattr(self, 'aquarium_container') or self.aquarium_container is None:
            return

        container = self.aquarium_container
        container_width = container.width()
        container_height = container.height()

        for fish in self.active_fish_sprites:
            # Random direction change (gentle)
            if random.random() < 0.008:  # Slightly more frequent but smaller changes
                fish.dx = fish.dx + random.choice([-0.5, -0.3, 0, 0.3, 0.5])
                fish.dy = fish.dy + random.choice([-0.5, -0.3, 0, 0.3, 0.5])
                # Stricter speed limits
                fish.dx = max(-1.2, min(1.2, fish.dx))
                fish.dy = max(-1, min(1, fish.dy))
                if abs(fish.dx) < 0.2:
                    fish.dx = 0.5 if random.random() > 0.5 else -0.5
                self.flip_fish_direction(fish)

            # Calculate new position
            new_x = fish.x + fish.dx
            new_y = fish.y + fish.dy

            bounced = False
            direction_changed = False
            WALL_PADDING = -7

            # Horizontal bounds
            if new_x <= WALL_PADDING:
                new_x = WALL_PADDING
                fish.dx = abs(fish.dx)
                bounced = True
                direction_changed = True
            elif new_x + fish.width >= container_width - WALL_PADDING:
                new_x = container_width - fish.width - WALL_PADDING
                fish.dx = -abs(fish.dx)
                bounced = True
                direction_changed = True

            # Vertical bounds
            if new_y <= WALL_PADDING:
                new_y = WALL_PADDING
                fish.dy = abs(fish.dy)
                bounced = True
            elif new_y + fish.height >= container_height - WALL_PADDING:
                new_y = container_height - fish.height - WALL_PADDING
                fish.dy = -abs(fish.dy)
                bounced = True

            # Flip if direction changed
            if direction_changed:
                self.flip_fish_direction(fish)

            # Move the fish
            fish.label.move(int(new_x), int(new_y))  # Convert to int for positioning
            fish.x = new_x
            fish.y = new_y

            # Speed variation on bounce (very gentle)
            if bounced and random.random() < 0.08:
                fish.dx = fish.dx + random.choice([-0.3, 0, 0.3])
                fish.dy = fish.dy + random.choice([-0.3, 0, 0.3])
                fish.dx = max(-1.2, min(1.2, fish.dx))
                fish.dy = max(-1, min(1, fish.dy))
                if abs(fish.dx) < 0.2:
                    fish.dx = 0.5 if random.random() > 0.5 else -0.5

    def flip_fish_direction(self, fish):
        """Flip the fish sprite sheet only if direction changed"""
        if not hasattr(fish, 'label') or not hasattr(fish.label, 'flip'):
            return

        # Determine if fish should be facing right (dx > 0) or left (dx < 0)
        should_face_right = fish.dx > 0

        # Check current facing (track it on the fish object)
        if not hasattr(fish, 'facing_right'):
            # Initialize based on current state
            fish.facing_right = not fish.label.is_flipped  # If flipped, facing right

        # Only flip if the desired facing doesn't match current facing
        if should_face_right != fish.facing_right:
            fish.label.flip()
            fish.facing_right = should_face_right

    def spawn_fish_sprite(self, fish_id):
        print(f"[UI] Spawning Fish : {fish_id}")

        MAX_FISH = 15
        if len(self.active_fish_sprites) >= MAX_FISH:
            # Make room for the new spawn!
            self.remove_oldest_fish()

            # If we are STILL at the limit (shouldn't happen), abort safely
            if len(self.active_fish_sprites) >= MAX_FISH:
                print(f"Maximum limit ({MAX_FISH}) reached. Cannot spawn more.")
                return

        container = self.aquarium_container

        padding = 10
        fish_width = 64
        fish_height = 64

        min_x = padding
        max_x = container.width() - fish_width - padding
        min_y = padding
        max_y = container.height() - fish_height - padding

        if min_x >= max_x or min_y >= max_y:
            start_x = 50
            start_y = 50
        else:
            start_x = random.randint(min_x, max_x)
            start_y = random.randint(min_y, max_y)

        # Build sprite sheet path (all fish use same naming convention)
        sprite_path = f"assets/{fish_id}_swim.png"

        # Check if sprite sheet exists
        if not os.path.exists(sprite_path):
            print(f"⚠️ WARNING: Sprite sheet not found: {sprite_path}")
            print(f"   Fish '{fish_id}' will not be spawned. Please add sprite sheet to assets folder.")
            return

        # Random initial direction
        initial_dx = random.choice([-1, -0.8, -0.5, 0.5, 0.8, 1])
        initial_dy = random.choice([-0.5, -0.3, 0, 0.3, 0.5])

        # Create sprite sheet fish
        fish_label = SpriteSheetFish(sprite_path, container)

        # All sprite sheets face left by default
        # Track which direction the fish is visually facing
        if initial_dx > 0:  # Moving right, need to flip
            fish_label.flip()
            fish_facing_right = True
        else:
            fish_facing_right = False

        fish_label.setGeometry(start_x, start_y, fish_width, fish_height)

        swimming_fish = SwimmingFish(
            fish_id=fish_id,  # <- Pass the ID here
            label=fish_label,
            sprite_path=sprite_path,
            x=start_x,
            y=start_y,
            width=fish_width,
            height=fish_height
        )

        swimming_fish.dx = initial_dx
        swimming_fish.dy = initial_dy
        swimming_fish.facing_right = fish_facing_right  # ← Store initial facing

        fish_label.show()
        fish_label.raise_()
        self.active_fish_sprites.append(swimming_fish)

        self.current_fish_count = len(self.active_fish_sprites)
        self.fish_count_label.setText(f"{self.current_fish_count} fish")

        print(f"✅ Fish spawned successfully! Total fish: {self.current_fish_count}")

    def remove_oldest_fish(self):
        """Removes the oldest NON-FAVORITE fish to make room"""
        favorites = self.time_manager.user_data.get("favorite_fish", [])

        # Find the oldest non-favorite fish
        fish_to_remove = None
        for fish in self.active_fish_sprites:
            if fish.fish_id not in favorites:
                fish_to_remove = fish
                break

        # Fallback: If somehow all 15 fish are favorites, just remove the oldest one
        if not fish_to_remove and self.active_fish_sprites:
            fish_to_remove = self.active_fish_sprites[0]

        if fish_to_remove:
            self.active_fish_sprites.remove(fish_to_remove)
            fish_to_remove.label.stop()
            fish_to_remove.label.deleteLater()
            print(f"Removed fish {fish_to_remove.fish_id} to make room.")

    def update_hud(self, live_stats, accumulated_active_time):
        current_wpm = live_stats.get("wpm", 0)
        total_chars = live_stats.get("total_chars", 0)

        self.wpm_card.set_value(current_wpm)
        self.chars_card.set_value(total_chars)
        self.focus_card.set_value(accumulated_active_time)

    def toggle_pin_status(self):
        if self.pin_state:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowStaysOnTopHint)
            self.pin_btn.setIcon(QIcon("assets/pin_activate_button.png"))
            self.pin_btn.setStyleSheet("background: transparent; border: none;")
            self.pin_state = False
        else:
            self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
            self.pin_btn.setIcon(QIcon("assets/pin_deactivate_button.png"))
            self.pin_btn.setStyleSheet("background: transparent; border: none;")
            self.pin_state = True
        self.show()

    def close_app(self):
        if hasattr(self, 'movement_timer'):
            self.movement_timer.stop()
        # Stop all fish animations
        for fish in self.active_fish_sprites:
            fish.label.stop()
        self.close()

    def minimize_app(self):
        self.showMinimized()

    def resizeEvent(self, event):
        """Update border widget geometry when window is resized"""
        super().resizeEvent(event)
        # Update the border widget to match the new window size
        self.border_widget.setGeometry(0, 0, self.width(), self.height())

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()