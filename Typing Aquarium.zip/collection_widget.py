# collection_widget.py

import json
import os
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QScrollArea,
                             QGridLayout, QLabel, QPushButton, QFrame)
from PyQt6.QtGui import QPixmap, QIcon
from PyQt6.QtCore import Qt, QSize, QTimer


class CollectionWindow(QWidget):
    """Separate window for collection view"""

    def __init__(self, time_manager, parent=None):
        super().__init__(parent)
        self.time_manager = time_manager
        self.setWindowTitle("Fish Collection")
        self.setFixedSize(400, 700)  # Fixed size, independent from main window
        self.setStyleSheet("background-color: rgba(7, 18, 35, 240); border-radius: 20px;")


class FishCard(QFrame):
    """Individual fish card in the collection grid"""

    def __init__(self, fish_data, is_owned, is_new, time_manager, parent=None):
        super().__init__(parent)
        self.fish_data = fish_data
        self.is_owned = is_owned
        self.is_new = is_new
        self.fish_id = fish_data["id"]
        self.time_manager = time_manager  # Store manager for saving

        self.setFixedSize(110, 130)
        self.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.05);
                border-radius: 12px;
            }
            QFrame:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # --- Favorite Button (Absolute Positioning in top right) ---
        favorites = self.time_manager.user_data.get("favorite_fish", [])
        is_fav = self.fish_id in favorites

        self.fav_btn = QPushButton("★" if is_fav else "☆", self)
        self.fav_btn.setGeometry(88, 4, 18, 18)  # X, Y, Width, Height
        self.update_star_style(is_fav)

        if is_owned:
            self.fav_btn.clicked.connect(self.toggle_favorite)
        else:
            self.fav_btn.hide()  # Can't favorite a locked fish
        # ----------------------------------------------------------------

        # Fish image (Restored image loading logic)
        self.image_label = QLabel()
        self.image_label.setFixedSize(64, 64)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setScaledContents(True)

        if is_owned:
            img_path = f"assets/{fish_data['id']}_swim.png"
            if not os.path.exists(img_path):
                img_path = f"assets/{fish_data['id']}_swim.gif"
            if not os.path.exists(img_path):
                img_path = "assets/default_fish.png"
        else:
            img_path = "assets/default_fish.png"

        pixmap = QPixmap(img_path)
        if not pixmap.isNull():
            self.image_label.setPixmap(pixmap.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio))

        layout.addWidget(self.image_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Fish name
        name_label = QLabel(fish_data["name"])
        name_label.setStyleSheet("""
            color: white;
            font-size: 11px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: transparent;
        """)
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(name_label)

        # Rarity badge
        rarity = fish_data.get("rarity", 50)
        if rarity >= 50:
            rarity_text = "COMMON"
            rarity_color = "#56D4C9"
        elif rarity >= 10:
            rarity_text = "RARE"
            rarity_color = "#9B59B6"
        else:
            rarity_text = "LEGENDARY"
            rarity_color = "#F39C12"

        rarity_label = QLabel(rarity_text)
        rarity_label.setStyleSheet(f"""
            color: {rarity_color};
            font-size: 9px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: rgba(0, 0, 0, 0.5);
            padding: 2px 6px;
            border-radius: 10px;
        """)
        rarity_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(rarity_label)

        # New badge
        if is_new and is_owned:
            self.new_badge = QLabel("NEW")
            self.new_badge.setStyleSheet("""
                color: #FF6B6B;
                font-size: 9px;
                font-weight: bold;
                font-family: 'DM Sans';
                background: rgba(0, 0, 0, 0.7);
                padding: 2px 6px;
                border-radius: 10px;
            """)
            self.new_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(self.new_badge)
        else:
            spacer = QLabel()
            spacer.setFixedHeight(18)
            layout.addWidget(spacer)

        # Lock icon for locked fish
        if not is_owned:
            lock_label = QLabel("🔒")
            lock_label.setStyleSheet("""
                color: rgba(255, 255, 255, 0.7);
                font-size: 20px;
                background: transparent;
            """)
            lock_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(lock_label)

        self.setLayout(layout)

    def update_star_style(self, is_fav):
        color = "#F39C12" if is_fav else "rgba(255, 255, 255, 0.3)"
        self.fav_btn.setStyleSheet(f"background: transparent; border: none; font-size: 16px; color: {color};")

    def toggle_favorite(self):
        favorites = self.time_manager.user_data.get("favorite_fish", [])

        if self.fish_id in favorites:
            favorites.remove(self.fish_id)
            is_fav = False
        else:
            if len(favorites) >= 15:
                print("Maximum tank capacity (15 favorites) reached!")
                return
            favorites.append(self.fish_id)
            is_fav = True

        # Save and update UI
        self.time_manager.user_data["favorite_fish"] = favorites
        self.time_manager.save_state()
        self.fav_btn.setText("★" if is_fav else "☆")
        self.update_star_style(is_fav)
        print(f"{'Added' if is_fav else 'Removed'} {self.fish_id} to favorites.")


class CollectionWidget(QWidget):
    """Collection tab - shows all fish in a grid"""

    def __init__(self, time_manager, parent=None):
        super().__init__(parent)
        self.time_manager = time_manager
        self.current_filter = "all"

        self.setup_ui()
        self.load_fish_data()
        self.apply_filter()

    def setup_ui(self):
        """Setup the collection widget UI"""
        self.setStyleSheet("background: transparent;")

        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Filter bar with discovery counter
        filter_bar = self.create_filter_bar()
        main_layout.addWidget(filter_bar)

        # Scrollable grid area (this will expand to fill available space)
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: rgba(255, 255, 255, 0.1);
                width: 6px;
                border-radius: 3px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 3px;
            }
        """)

        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(12)
        self.grid_layout.setContentsMargins(12, 12, 12, 12)

        self.scroll_area.setWidget(self.grid_container)
        main_layout.addWidget(self.scroll_area)

    def create_filter_bar(self):
        """Create filter tabs (All, Owned, Locked) with discovery counter"""
        filter_bar = QWidget()
        filter_bar.setFixedHeight(30)  # FIXED: Was 0, making tabs invisible!
        filter_bar.setStyleSheet("background: transparent;")

        layout = QHBoxLayout(filter_bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(8)

        # Filter buttons
        self.all_btn = self.create_filter_button("All")
        self.owned_btn = self.create_filter_button("Owned")
        self.locked_btn = self.create_filter_button("Locked")

        self.set_active_filter(self.all_btn)

        self.all_btn.clicked.connect(lambda: self.set_filter("all"))
        self.owned_btn.clicked.connect(lambda: self.set_filter("owned"))
        self.locked_btn.clicked.connect(lambda: self.set_filter("locked"))

        layout.addWidget(self.all_btn)
        layout.addWidget(self.owned_btn)
        layout.addWidget(self.locked_btn)
        layout.addStretch()

        # Discovery counter (right-aligned)
        self.discovery_label = QLabel()
        self.discovery_label.setStyleSheet("""
            color: #56D4C9;
            font-size: 12px;
            font-weight: bold;
            font-family: 'DM Sans';
            background: transparent;
        """)
        layout.addWidget(self.discovery_label)

        return filter_bar

    def create_filter_button(self, text):
        """Create a filter tab button"""
        btn = QPushButton(text)
        btn.setFixedSize(60, 20)  # Adjusted width so text fits
        btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: rgba(255, 255, 255, 0.6);
                border: none;
                font-size: 12px;
                font-family: 'DM Sans';
            }
            QPushButton:hover {
                color: white;
            }
        """)
        return btn

    def set_active_filter(self, active_btn):
        """Update active filter button styling"""
        for btn in [self.all_btn, self.owned_btn, self.locked_btn]:
            btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: rgba(255, 255, 255, 0.6);
                    border: none;
                    font-size: 12px;
                    font-family: 'DM Sans';
                }
                QPushButton:hover {
                    color: white;
                }
            """)

        active_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #56D4C9;
                border: none;
                font-size: 12px;
                font-family: 'DM Sans';
                font-weight: bold;
            }
        """)

    def set_filter(self, filter_type):
        """Set current filter and refresh grid"""
        self.current_filter = filter_type

        if filter_type == "all":
            self.set_active_filter(self.all_btn)
        elif filter_type == "owned":
            self.set_active_filter(self.owned_btn)
        else:
            self.set_active_filter(self.locked_btn)

        self.apply_filter()

    def load_fish_data(self):
        """Load fish data from fish.json"""
        try:
            with open("fish.json", "r") as f:
                self.all_fish = json.load(f)
            print(f"Loaded {len(self.all_fish)} fish")
        except Exception as e:
            print(f"Error loading fish.json: {e}")
            self.all_fish = []

    def apply_filter(self):
        """Apply current filter and sort, then populate grid"""
        if not self.all_fish:
            return

        owned_ids = self.time_manager.user_data.get("owned_fish", [])
        viewed_ids = self.time_manager.user_data.get("viewed_fish", [])

        filtered_fish = []
        for fish in self.all_fish:
            is_owned = fish["id"] in owned_ids
            is_new = is_owned and fish["id"] not in viewed_ids

            if self.current_filter == "all":
                filtered_fish.append((fish, is_owned, is_new))
            elif self.current_filter == "owned" and is_owned:
                filtered_fish.append((fish, is_owned, is_new))
            elif self.current_filter == "locked" and not is_owned:
                filtered_fish.append((fish, is_owned, is_new))

        # Sort by rarity (lower number = rarer, so common first then rare then legendary)
        filtered_fish.sort(key=lambda x: x[0].get("rarity", 50), reverse=True)

        # Update discovery counter
        owned_count = len(owned_ids)
        total_count = len(self.all_fish)
        self.discovery_label.setText(f"{owned_count}/{total_count} discovered")

        self.populate_grid(filtered_fish)

    def populate_grid(self, fish_list):
        """Populate the grid with fish cards"""
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        columns = 3
        for index, (fish, is_owned, is_new) in enumerate(fish_list):
            row = index // columns
            col = index % columns

            # FIXED: Uses the single correct version with time_manager passed in
            card = FishCard(fish, is_owned, is_new, self.time_manager)
            card.fish_id = fish["id"]
            card.is_new_flag = is_new

            # Note: Do not override mousePressEvent directly over the star button
            card.mousePressEvent = lambda e, c=card: self.on_card_clicked(c)
            self.grid_layout.addWidget(card, row, col)

    def on_card_clicked(self, card):
        """Handle fish card click - mark as viewed if new"""
        fish_id = card.fish_id
        is_new = card.is_new_flag

        if is_new:
            viewed_ids = self.time_manager.user_data.get("viewed_fish", [])
            if fish_id not in viewed_ids:
                viewed_ids.append(fish_id)
                self.time_manager.user_data["viewed_fish"] = viewed_ids
                self.time_manager.save_state()
            self.apply_filter()

        print(f"Clicked on fish: {fish_id}")

    def showEvent(self, event):
        """Refresh when tab becomes visible"""
        super().showEvent(event)
        self.apply_filter()